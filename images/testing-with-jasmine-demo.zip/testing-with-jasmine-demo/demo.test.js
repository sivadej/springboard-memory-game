const nums = [1, 2, 3, 4, 5];
const expected = [1, 3];

const evens = require("./bad-names");
const indexesOfEvens = require("./good-names");

it('bad ver should work', function () {
  expect(evens(nums)).toEqual(expected);
});

it('good ver should work', function () {
  expect(indexesOfEvens(nums)).toEqual(expected);
});
