/* Return indexes of even numbers in list. */

function indexesOfEvens(nums) {
  let indexes = [];

  for (let i = 0; i < nums.length; i++) {
    if (nums[i] % 2 === 0) {
      indexes.push(i);
    }
  }

  return indexes;
}

module.exports = indexesOfEvens

